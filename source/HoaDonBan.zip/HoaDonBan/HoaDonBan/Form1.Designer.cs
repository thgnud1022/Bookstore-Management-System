﻿namespace HoaDonBan
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label1 = new Label();
            groupBox1 = new GroupBox();
            dtNgayban = new DateTimePicker();
            textBoxTenNV = new TextBox();
            textBoxMaNV = new TextBox();
            textBoxTenKH = new TextBox();
            textBoxDCKH = new TextBox();
            textBoxSDTKH = new TextBox();
            textBoxMaKH = new TextBox();
            textBoxSoHDB = new TextBox();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            panel2 = new Panel();
            button2 = new Button();
            button1 = new Button();
            btnThem = new Button();
            panel3 = new Panel();
            btnThemCT = new Button();
            groupBox2 = new GroupBox();
            textBoxThanhtien = new TextBox();
            textBoxSoluong = new TextBox();
            textBoxTenHH = new TextBox();
            textBoxDongia = new TextBox();
            textBoxMaHH = new TextBox();
            label14 = new Label();
            label11 = new Label();
            label13 = new Label();
            label10 = new Label();
            label12 = new Label();
            dgvChitiet = new DataGridView();
            label15 = new Label();
            textBoxTongthanhtien = new TextBox();
            panel1.SuspendLayout();
            groupBox1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvChitiet).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(label1);
            panel1.Controls.Add(groupBox1);
            panel1.Location = new Point(0, -3);
            panel1.Name = "panel1";
            panel1.Size = new Size(1531, 262);
            panel1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.HotTrack;
            label1.Location = new Point(681, 12);
            label1.Name = "label1";
            label1.Size = new Size(305, 32);
            label1.TabIndex = 1;
            label1.Text = "HOÁ ĐƠN BÁN HÀNG";
            label1.TextAlign = ContentAlignment.TopCenter;
            label1.Click += label1_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(dtNgayban);
            groupBox1.Controls.Add(textBoxTenNV);
            groupBox1.Controls.Add(textBoxMaNV);
            groupBox1.Controls.Add(textBoxTenKH);
            groupBox1.Controls.Add(textBoxDCKH);
            groupBox1.Controls.Add(textBoxSDTKH);
            groupBox1.Controls.Add(textBoxMaKH);
            groupBox1.Controls.Add(textBoxSoHDB);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(26, 64);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(1529, 192);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thông tin chung";
            // 
            // dtNgayban
            // 
            dtNgayban.Font = new Font("Times New Roman", 12F);
            dtNgayban.Format = DateTimePickerFormat.Short;
            dtNgayban.Location = new Point(186, 74);
            dtNgayban.Name = "dtNgayban";
            dtNgayban.Size = new Size(237, 30);
            dtNgayban.TabIndex = 16;
            dtNgayban.ValueChanged += dateTimePicker1_ValueChanged;
            // 
            // textBoxTenNV
            // 
            textBoxTenNV.Font = new Font("Times New Roman", 12F);
            textBoxTenNV.Location = new Point(186, 154);
            textBoxTenNV.Name = "textBoxTenNV";
            textBoxTenNV.Size = new Size(480, 30);
            textBoxTenNV.TabIndex = 15;
            // 
            // textBoxMaNV
            // 
            textBoxMaNV.Font = new Font("Times New Roman", 12F);
            textBoxMaNV.Location = new Point(186, 114);
            textBoxMaNV.Name = "textBoxMaNV";
            textBoxMaNV.Size = new Size(237, 30);
            textBoxMaNV.TabIndex = 13;
            // 
            // textBoxTenKH
            // 
            textBoxTenKH.Font = new Font("Times New Roman", 12F);
            textBoxTenKH.Location = new Point(995, 74);
            textBoxTenKH.Name = "textBoxTenKH";
            textBoxTenKH.Size = new Size(472, 30);
            textBoxTenKH.TabIndex = 12;
            // 
            // textBoxDCKH
            // 
            textBoxDCKH.Font = new Font("Times New Roman", 12F);
            textBoxDCKH.Location = new Point(995, 114);
            textBoxDCKH.Name = "textBoxDCKH";
            textBoxDCKH.Size = new Size(472, 30);
            textBoxDCKH.TabIndex = 11;
            // 
            // textBoxSDTKH
            // 
            textBoxSDTKH.Font = new Font("Times New Roman", 12F);
            textBoxSDTKH.Location = new Point(995, 154);
            textBoxSDTKH.Name = "textBoxSDTKH";
            textBoxSDTKH.Size = new Size(216, 30);
            textBoxSDTKH.TabIndex = 10;
            textBoxSDTKH.TextChanged += textBoxSDTKH_TextChanged;
            // 
            // textBoxMaKH
            // 
            textBoxMaKH.Font = new Font("Times New Roman", 12F);
            textBoxMaKH.Location = new Point(995, 34);
            textBoxMaKH.Name = "textBoxMaKH";
            textBoxMaKH.Size = new Size(216, 30);
            textBoxMaKH.TabIndex = 9;
            // 
            // textBoxSoHDB
            // 
            textBoxSoHDB.Font = new Font("Times New Roman", 12F);
            textBoxSoHDB.Location = new Point(186, 34);
            textBoxSoHDB.Name = "textBoxSoHDB";
            textBoxSoHDB.Size = new Size(237, 30);
            textBoxSoHDB.TabIndex = 8;
            textBoxSoHDB.TextChanged += textBox1_TextChanged;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Times New Roman", 12F);
            label9.ForeColor = SystemColors.HotTrack;
            label9.Location = new Point(827, 164);
            label9.Name = "label9";
            label9.Size = new Size(120, 22);
            label9.TabIndex = 7;
            label9.Text = "Số điện thoại:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Times New Roman", 12F);
            label8.ForeColor = SystemColors.HotTrack;
            label8.Location = new Point(827, 123);
            label8.Name = "label8";
            label8.Size = new Size(74, 22);
            label8.TabIndex = 6;
            label8.Text = "Địa chỉ:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 12F);
            label7.ForeColor = SystemColors.HotTrack;
            label7.Location = new Point(827, 80);
            label7.Name = "label7";
            label7.Size = new Size(137, 22);
            label7.TabIndex = 5;
            label7.Text = "Tên khách hàng:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 12F);
            label6.ForeColor = SystemColors.HotTrack;
            label6.Location = new Point(827, 40);
            label6.Name = "label6";
            label6.Size = new Size(133, 22);
            label6.TabIndex = 4;
            label6.Text = "Mã khách hàng:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 12F);
            label5.ForeColor = SystemColors.HotTrack;
            label5.Location = new Point(39, 164);
            label5.Name = "label5";
            label5.Size = new Size(126, 22);
            label5.TabIndex = 3;
            label5.Text = "Tên nhân viên:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 12F);
            label4.ForeColor = SystemColors.HotTrack;
            label4.Location = new Point(39, 123);
            label4.Name = "label4";
            label4.Size = new Size(122, 22);
            label4.TabIndex = 2;
            label4.Text = "Mã nhân viên:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 12F);
            label3.ForeColor = SystemColors.HotTrack;
            label3.Location = new Point(39, 80);
            label3.Name = "label3";
            label3.Size = new Size(90, 22);
            label3.TabIndex = 1;
            label3.Text = "Ngày bán:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 12F);
            label2.ForeColor = SystemColors.HotTrack;
            label2.Location = new Point(39, 40);
            label2.Name = "label2";
            label2.Size = new Size(105, 22);
            label2.TabIndex = 0;
            label2.Text = "Số hoá đơn:";
            // 
            // panel2
            // 
            panel2.Controls.Add(button2);
            panel2.Controls.Add(button1);
            panel2.Controls.Add(btnThem);
            panel2.Location = new Point(0, 263);
            panel2.Name = "panel2";
            panel2.Size = new Size(1555, 61);
            panel2.TabIndex = 1;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.GradientInactiveCaption;
            button2.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(1184, 9);
            button2.Name = "button2";
            button2.Size = new Size(196, 40);
            button2.TabIndex = 2;
            button2.Text = "Làm mới";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.GradientInactiveCaption;
            button1.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(681, 9);
            button1.Name = "button1";
            button1.Size = new Size(196, 40);
            button1.TabIndex = 1;
            button1.Text = "Huỷ";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click_1;
            // 
            // btnThem
            // 
            btnThem.BackColor = SystemColors.GradientInactiveCaption;
            btnThem.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnThem.Location = new Point(212, 9);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(196, 40);
            btnThem.TabIndex = 0;
            btnThem.Text = "Thêm";
            btnThem.UseVisualStyleBackColor = false;
            btnThem.Click += btnThem_Click;
            // 
            // panel3
            // 
            panel3.Controls.Add(btnThemCT);
            panel3.Controls.Add(groupBox2);
            panel3.Location = new Point(26, 330);
            panel3.Name = "panel3";
            panel3.Size = new Size(1505, 195);
            panel3.TabIndex = 2;
            // 
            // btnThemCT
            // 
            btnThemCT.BackColor = SystemColors.GradientInactiveCaption;
            btnThemCT.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnThemCT.Location = new Point(17, 147);
            btnThemCT.Name = "btnThemCT";
            btnThemCT.Size = new Size(196, 40);
            btnThemCT.TabIndex = 1;
            btnThemCT.Text = "Thêm";
            btnThemCT.UseVisualStyleBackColor = false;
            btnThemCT.Click += button1_Click;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(textBoxThanhtien);
            groupBox2.Controls.Add(textBoxSoluong);
            groupBox2.Controls.Add(textBoxTenHH);
            groupBox2.Controls.Add(textBoxDongia);
            groupBox2.Controls.Add(textBoxMaHH);
            groupBox2.Controls.Add(label14);
            groupBox2.Controls.Add(label11);
            groupBox2.Controls.Add(label13);
            groupBox2.Controls.Add(label10);
            groupBox2.Controls.Add(label12);
            groupBox2.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox2.Location = new Point(0, 18);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(1505, 123);
            groupBox2.TabIndex = 0;
            groupBox2.TabStop = false;
            groupBox2.Text = "Chi tiết hoá đơn";
            // 
            // textBoxThanhtien
            // 
            textBoxThanhtien.Font = new Font("Times New Roman", 12F);
            textBoxThanhtien.Location = new Point(1137, 88);
            textBoxThanhtien.Name = "textBoxThanhtien";
            textBoxThanhtien.Size = new Size(237, 30);
            textBoxThanhtien.TabIndex = 25;
            // 
            // textBoxSoluong
            // 
            textBoxSoluong.Font = new Font("Times New Roman", 12F);
            textBoxSoluong.Location = new Point(678, 87);
            textBoxSoluong.Name = "textBoxSoluong";
            textBoxSoluong.Size = new Size(237, 30);
            textBoxSoluong.TabIndex = 24;
            // 
            // textBoxTenHH
            // 
            textBoxTenHH.Font = new Font("Times New Roman", 12F);
            textBoxTenHH.Location = new Point(678, 41);
            textBoxTenHH.Name = "textBoxTenHH";
            textBoxTenHH.Size = new Size(237, 30);
            textBoxTenHH.TabIndex = 23;
            textBoxTenHH.TextChanged += textBoxTenHH_TextChanged;
            // 
            // textBoxDongia
            // 
            textBoxDongia.Font = new Font("Times New Roman", 12F);
            textBoxDongia.Location = new Point(164, 88);
            textBoxDongia.Name = "textBoxDongia";
            textBoxDongia.Size = new Size(237, 30);
            textBoxDongia.TabIndex = 22;
            // 
            // textBoxMaHH
            // 
            textBoxMaHH.Font = new Font("Times New Roman", 12F);
            textBoxMaHH.Location = new Point(164, 33);
            textBoxMaHH.Name = "textBoxMaHH";
            textBoxMaHH.Size = new Size(237, 30);
            textBoxMaHH.TabIndex = 17;
            textBoxMaHH.TextChanged += textBoxMaHH_TextChanged;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Times New Roman", 12F);
            label14.ForeColor = SystemColors.HotTrack;
            label14.Location = new Point(1009, 88);
            label14.Name = "label14";
            label14.Size = new Size(98, 22);
            label14.TabIndex = 21;
            label14.Text = "Thành tiền:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Times New Roman", 12F);
            label11.ForeColor = SystemColors.HotTrack;
            label11.Location = new Point(17, 41);
            label11.Name = "label11";
            label11.Size = new Size(116, 22);
            label11.TabIndex = 17;
            label11.Text = "Mã hàng hoá:";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Times New Roman", 12F);
            label13.ForeColor = SystemColors.HotTrack;
            label13.Location = new Point(524, 88);
            label13.Name = "label13";
            label13.Size = new Size(88, 22);
            label13.TabIndex = 20;
            label13.Text = "Số lượng:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Times New Roman", 12F);
            label10.ForeColor = SystemColors.HotTrack;
            label10.Location = new Point(524, 41);
            label10.Name = "label10";
            label10.Size = new Size(120, 22);
            label10.TabIndex = 18;
            label10.Text = "Tên hàng hoá:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Times New Roman", 12F);
            label12.ForeColor = SystemColors.HotTrack;
            label12.Location = new Point(17, 88);
            label12.Name = "label12";
            label12.Size = new Size(79, 22);
            label12.TabIndex = 19;
            label12.Text = "Đơn giá:";
            // 
            // dgvChitiet
            // 
            dgvChitiet.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvChitiet.BackgroundColor = SystemColors.GradientActiveCaption;
            dgvChitiet.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvChitiet.GridColor = SystemColors.ControlDarkDark;
            dgvChitiet.Location = new Point(26, 531);
            dgvChitiet.Name = "dgvChitiet";
            dgvChitiet.RowHeadersWidth = 51;
            dgvChitiet.Size = new Size(1503, 391);
            dgvChitiet.TabIndex = 3;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Times New Roman", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label15.ForeColor = SystemColors.ControlText;
            label15.Location = new Point(1035, 945);
            label15.Name = "label15";
            label15.Size = new Size(151, 23);
            label15.TabIndex = 26;
            label15.Text = "Tổng thành tiền:";
            // 
            // textBoxTongthanhtien
            // 
            textBoxTongthanhtien.Font = new Font("Times New Roman", 12F);
            textBoxTongthanhtien.Location = new Point(1256, 942);
            textBoxTongthanhtien.Name = "textBoxTongthanhtien";
            textBoxTongthanhtien.Size = new Size(237, 30);
            textBoxTongthanhtien.TabIndex = 26;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1552, 986);
            Controls.Add(textBoxTongthanhtien);
            Controls.Add(label15);
            Controls.Add(dgvChitiet);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "Form1";
            Text = "Hoá đơn bán hàng";
            Load += Form1_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            panel2.ResumeLayout(false);
            panel3.ResumeLayout(false);
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvChitiet).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private GroupBox groupBox1;
        private Label label2;
        private TextBox textBoxSoHDB;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private DateTimePicker dtNgayban;
        private TextBox textBoxTenNV;
        private TextBox textBoxMaNV;
        private TextBox textBoxTenKH;
        private TextBox textBoxDCKH;
        private TextBox textBoxSDTKH;
        private TextBox textBoxMaKH;
        private Panel panel2;
        private Button btnThem;
        private Panel panel3;
        private GroupBox groupBox2;
        private Label label14;
        private Label label11;
        private Label label13;
        private Label label10;
        private Label label12;
        private TextBox textBoxThanhtien;
        private TextBox textBoxSoluong;
        private TextBox textBoxTenHH;
        private TextBox textBoxDongia;
        private TextBox textBoxMaHH;
        private DataGridView dgvChitiet;
        private Label label15;
        private TextBox textBoxTongthanhtien;
        private Button btnThemCT;
        private Button button1;
        private Button button2;
    }
}
