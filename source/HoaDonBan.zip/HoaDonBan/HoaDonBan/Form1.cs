﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace HoaDonBan
{
    public partial class Form1 : Form
    {
        string connectionString = "Data Source=DESKTOP-658G9LP;Initial Catalog=QLCH;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";
        private DataTable dtChiTiet;
        private string maNVDangNhap = "NV001"; // Giả lập mã nhân viên

        // Dữ liệu tạm
        private string maHH;
        private decimal giaBan;
        private bool isViewingInvoice = false;

        public Form1()
        {
            InitializeComponent();
            InitDataTable();
            LayTenNhanVien();


            textBoxSDTKH.KeyDown += txtSDTKH_KeyDown;
            textBoxTenHH.TextChanged += textBoxTenHH_TextChanged;
            textBoxTenHH.KeyDown += txtTenHH_KeyDown;
            textBoxSoluong.KeyDown += txtSoLuong_KeyDown;
            textBoxSoHDB.KeyDown += textBoxSoHDB_KeyDown;
            dgvChitiet.CellDoubleClick += dgvChitiet_CellDoubleClick;
            textBoxThanhtien.ReadOnly = true;
            textBoxTongthanhtien.ReadOnly = true;
        }

        //private void LaySoHoaDonTiepTheo()
        //{
        //    using (SqlConnection conn = new SqlConnection(connectionString))
        //    using (SqlCommand cmd = new SqlCommand("sp_SoHDBtt", conn))
        //    {
        //        cmd.CommandType = CommandType.StoredProcedure;

        //        SqlParameter soHDBParam = new SqlParameter("@SoHDB", SqlDbType.Char, 10);
        //        soHDBParam.Direction = ParameterDirection.Output;
        //        cmd.Parameters.Add(soHDBParam);

        //        conn.Open();
        //        cmd.ExecuteNonQuery();

        //        textBoxSoHDB.Text = soHDBParam.Value.ToString();
        //    }
        //}

        private void InitDataTable()
        {
            dtChiTiet = new DataTable();
            dtChiTiet.Columns.Add("Mã hàng hoá", typeof(string));
            dtChiTiet.Columns.Add("Số lượng bán", typeof(int));
            dtChiTiet.Columns.Add("Thành tiền", typeof(decimal));
            dgvChitiet.DataSource = dtChiTiet;
        }

        private void LayTenNhanVien()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT TenNV FROM NHANVIEN WHERE MaNV = @MaNV";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@MaNV", maNVDangNhap);

                conn.Open();
                textBoxTenNV.Text = cmd.ExecuteScalar()?.ToString();
                textBoxMaNV.Text = maNVDangNhap;
            }
        }

        private bool IsValidPhoneNumber(string phoneNumber)
        {
            // SĐT Việt Nam hợp lệ: bắt đầu bằng 03, 05, 07, 08, 09 + 8 chữ số nữa => tổng 10 số
            string pattern = @"^(03|05|07|08|09)\d{8}$";
            return Regex.IsMatch(phoneNumber, pattern);
        }

        private void txtSDTKH_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string sdt = textBoxSDTKH.Text.Trim();

                // Kiểm tra tính hợp lệ của số điện thoại trước khi truy vấn
                if (!IsValidPhoneNumber(sdt))
                {
                    MessageBox.Show(
                        "Số điện thoại không hợp lệ.\nVui lòng nhập đúng định dạng 10 số và bắt đầu bằng 03, 05, 07, 08 hoặc 09.",
                        "Cảnh báo",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                    textBoxSDTKH.Focus();
                    e.SuppressKeyPress = true; // Ngăn tiếng "ding"
                    return;
                }
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "SELECT MaKH, TenKH, DCKH FROM KHACHHANG WHERE SDTKH = @SDTKH";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@SDTKH", textBoxSDTKH.Text.Trim());

                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        textBoxMaKH.Text = reader["MaKH"].ToString();
                        textBoxTenKH.Text = reader["TenKH"].ToString();
                        textBoxDCKH.Text = reader["DCKH"].ToString();

                        textBoxMaKH.ReadOnly = true;
                        textBoxTenKH.ReadOnly = true;
                        textBoxDCKH.ReadOnly = true;

                        reader.Close();

                        // Gọi stored procedure để lấy số hóa đơn tiếp theo
                        using (SqlCommand cmd1 = new SqlCommand("sp_SoHDBtt", conn))
                        {
                            cmd1.CommandType = CommandType.StoredProcedure;

                            SqlParameter soHDBParam = new SqlParameter("@SoHDB", SqlDbType.Char, 10)
                            {
                                Direction = ParameterDirection.Output
                            };
                            cmd1.Parameters.Add(soHDBParam);
                            cmd1.ExecuteNonQuery();

                            textBoxSoHDB.Text = soHDBParam.Value.ToString();
                        }
                    }
                    else
                    {
                        reader.Close();
                        MessageBox.Show("Không tìm thấy khách hàng!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textBoxMaKH.ReadOnly = false;
                        textBoxTenKH.ReadOnly = false;
                        textBoxDCKH.ReadOnly = false;
                    }
                }
            }
        }

        private async void textBoxTenHH_TextChanged(object sender, EventArgs e)
        {
            string keyword = textBoxTenHH.Text.Trim();

            if (keyword.Length < 2) return; // Chỉ tìm gợi ý khi nhập >= 2 ký tự

            await Task.Delay(200); // Debounce: chờ người dùng ngừng gõ trong 200ms

            if (textBoxTenHH.Text.Trim() != keyword) return; // Kiểm tra người dùng có tiếp tục gõ không

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "SELECT TenHH FROM HANGHOA WHERE TenHH LIKE @TenHH";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@TenHH", "%" + keyword + "%");

                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    AutoCompleteStringCollection collection = new AutoCompleteStringCollection();
                    while (reader.Read())
                    {
                        collection.Add(reader["TenHH"].ToString());
                    }

                    // Chỉ cập nhật khi có kết quả mới
                    textBoxTenHH.AutoCompleteMode = AutoCompleteMode.Suggest;
                    textBoxTenHH.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    textBoxTenHH.AutoCompleteCustomSource = collection;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi gợi ý tên hàng hoá: " + ex.Message);
            }
        }




        private void txtTenHH_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string tenHH = textBoxTenHH.Text.Trim();

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    // Gọi hàm kiểm tra tồn tại hàng hóa
                    SqlCommand checkCmd = new SqlCommand("SELECT dbo.fn_KiemTraTonTaiHangHoa(@TenHH)", conn);
                    checkCmd.Parameters.AddWithValue("@TenHH", tenHH);
                    int ketQua = (int)checkCmd.ExecuteScalar();

                    if (ketQua == 1)
                    {
                        MessageBox.Show("Hàng hóa không tồn tại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                        textBoxMaHH.ReadOnly = false;
                        textBoxDongia.ReadOnly = false;
                        return;
                    }
                    else if (ketQua == 2)
                    {
                        MessageBox.Show("Hàng hóa đã bị xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                        textBoxMaHH.ReadOnly = false;
                        textBoxDongia.ReadOnly = false;
                        return;
                    }

                    // Nếu còn hoạt động thì truy vấn mã hàng và giá bán
                    string query = @"
                                    SELECT hh.MaHH, g.GiaBan 
                                    FROM HANGHOA hh
                                    JOIN GIABAN g ON hh.MaHH = g.MaHH
                                    WHERE hh.TenHH = @TenHH AND g.NgayApDung = (
                                        SELECT MAX(NgayApDung) FROM GIABAN WHERE MaHH = hh.MaHH
                                    )";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@TenHH", tenHH);

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        maHH = reader["MaHH"].ToString();
                        giaBan = Convert.ToDecimal(reader["GiaBan"]);
                        textBoxMaHH.Text = maHH;
                        textBoxDongia.Text = giaBan.ToString("N2");

                        // Tên hàng hóa sau khi tìm thấy
                        textBoxMaHH.ReadOnly = true;
                        textBoxDongia.ReadOnly = true;
                    }
                    else
                    {
                        MessageBox.Show("Không tìm thấy giá bán cho hàng hóa này!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                        textBoxMaHH.ReadOnly = false;
                        textBoxDongia.ReadOnly = false;
                    }
                }
            }
        }

        private void txtSoLuong_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                int slBan;
                // Nếu không parse được hoặc slBan <= 0 thì hiện lỗi
                if (!int.TryParse(textBoxSoluong.Text.Trim(), out slBan) || slBan <= 0)
                {
                    MessageBox.Show("Vui lòng nhập số lượng hợp lệ (số nguyên dương).", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBoxSoluong.Focus();
                    return;
                }

                int heSo = 1;

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("SELECT HeSoQuyDoi FROM HANGHOA WHERE MaHH = @MaHH", conn);
                    cmd.Parameters.AddWithValue("@MaHH", maHH);
                    conn.Open();
                    heSo = Convert.ToInt32(cmd.ExecuteScalar());
                }
                decimal thanhTien = 0;
                if (heSo == 1)
                {
                    thanhTien = slBan * giaBan;
                }
                else
                {
                    int slNguyen = slBan / heSo;
                    int slLe = slBan - slNguyen * heSo;

                    thanhTien = (slNguyen * heSo * 0.95m + slLe) * giaBan;
                }


                textBoxThanhtien.Text = thanhTien.ToString("N2");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataRow row = dtChiTiet.NewRow();
            row["Mã hàng hoá"] = maHH;
            row["Số lượng bán"] = int.Parse(textBoxSoluong.Text);
            row["Thành tiền"] = decimal.Parse(textBoxThanhtien.Text);
            dtChiTiet.Rows.Add(row);

            decimal tong = dtChiTiet.AsEnumerable().Sum(r => r.Field<decimal>("Thành tiền"));
            textBoxTongthanhtien.Text = tong.ToString("N2");

            textBoxTenHH.Clear();
            textBoxSoluong.Clear();
            textBoxDongia.Clear();
            textBoxThanhtien.Clear();
            textBoxMaHH.Clear();
        }


        //Xoá bản ghi nếu nhập sai
        private void dgvChitiet_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (isViewingInvoice)
            {
                return;
            }
            if (e.RowIndex >= 0 && e.RowIndex < dgvChitiet.Rows.Count)
            {
                // Hỏi người dùng xác nhận xoá
                DialogResult result = MessageBox.Show(
                    "Bạn có chắc chắn muốn xoá dòng này?",
                    "Xác nhận xoá",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question
                );

                if (result == DialogResult.Yes)
                {
                    // Xoá dòng khỏi DataTable
                    dtChiTiet.Rows.RemoveAt(e.RowIndex);

                    // Cập nhật lại tổng thành tiền
                    decimal tong = dtChiTiet.AsEnumerable().Sum(r => r.Field<decimal>("Thành tiền"));
                    textBoxTongthanhtien.Text = tong.ToString("N2");

                    MessageBox.Show("Đã xoá dòng khỏi danh sách chi tiết.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("spThemMoiHoaDonBan", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@NgayBan", dtNgayban.Value);
                cmd.Parameters.AddWithValue("@MaKH", textBoxMaKH.Text);
                cmd.Parameters.AddWithValue("@MaNV", maNVDangNhap);
                cmd.Parameters.AddWithValue("@TongThanhTien", decimal.Parse(textBoxTongthanhtien.Text));

                SqlParameter chitietParam = cmd.Parameters.AddWithValue("@ChiTietBan", dtChiTiet);
                chitietParam.SqlDbType = SqlDbType.Structured;
                chitietParam.TypeName = "dbo.ChiTietPhieuBan";

                SqlParameter reParam = new SqlParameter("@re", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(reParam);

                conn.Open();
                cmd.ExecuteNonQuery();
                int result = (int)reParam.Value;

                if (result == 0)
                {
                    MessageBox.Show("Thêm hóa đơn thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dtChiTiet.Clear(); // Xóa dữ liệu chi tiết
                    textBoxMaKH.Clear();
                    textBoxTenKH.Clear();
                    textBoxDCKH.Clear();
                    textBoxSDTKH.Clear();
                    textBoxTongthanhtien.Clear();
                    textBoxTenHH.Clear();
                    textBoxDongia.Clear();
                    textBoxSoluong.Clear();
                    textBoxThanhtien.Clear();
                    dgvChitiet.Refresh();
                    textBoxSoHDB.Clear();
                    isViewingInvoice = false; // Reset trạng thái
                }

                else if (result == 1)
                    MessageBox.Show("lỗi thêm mới hoá đơn bán.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else if (result == 2)
                    MessageBox.Show("lỗi thêm mới chi tiết hoá đơn bán.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                    MessageBox.Show("lỗi cập nhật tồn kho.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBoxMaHH_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        // Huỷ hoá đơn

        private void textBoxSoHDB_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; // Ngăn tiếng beep khi nhấn Enter
                KiemTraVaHienThiHoaDon();
            }
        }

        private void KiemTraVaHienThiHoaDon()
        {
            string soHDB = textBoxSoHDB.Text.Trim();
            string maNV = textBoxMaNV.Text.Trim(); // giả định textbox này chứa mã nhân viên hiện tại

            if (string.IsNullOrEmpty(soHDB))
            {
                MessageBox.Show("Vui lòng nhập số hóa đơn.");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand("sp_KiemTraHoaDon", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@SoHDB", soHDB);
                cmd.Parameters.AddWithValue("@MaNV", maNV);

                SqlParameter ketQuaParam = new SqlParameter("@KetQua", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(ketQuaParam);

                cmd.ExecuteNonQuery();
                int ketQua = (int)ketQuaParam.Value;

                if (ketQua == 1)
                {
                    MessageBox.Show("Không tồn tại hóa đơn này.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                else if (ketQua == 2)
                {
                    MessageBox.Show("Bạn không có quyền trên hóa đơn này.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Nếu hợp lệ, hiển thị thông tin hóa đơn
                string query = @"SELECT SoHDB, NgayBan, TongThanhTien, kh.MaKH, TenKH, DCKH, SDTKH FROM BAN b JOIN KHACHHANG kh ON b.MaKH = kh.MaKH WHERE SoHDB = @SoHDB";
                SqlCommand infoCmd = new SqlCommand(query, conn);
                infoCmd.Parameters.AddWithValue("@SoHDB", soHDB);
                SqlDataReader reader = infoCmd.ExecuteReader();
                if (reader.Read())
                {
                    dtNgayban.Text = Convert.ToDateTime(reader["NgayBan"]).ToString("dd/MM/yyyy");
                    textBoxMaKH.Text = reader["MaKH"].ToString();
                    textBoxTenKH.Text = reader["TenKH"].ToString();
                    textBoxDCKH.Text = reader["DCKH"].ToString();
                    textBoxSDTKH.Text = reader["SDTKH"].ToString();
                    textBoxTongthanhtien.Text = Convert.ToDecimal(reader["TongThanhTien"]).ToString("N2");
                }
                reader.Close();

                // Hiển thị chi tiết hóa đơn
                string ctQuery = @"SELECT MaHH, SLBan, ThanhTien FROM CTPHIEUBAN WHERE SoHDB = @SoHDB";
                SqlDataAdapter da = new SqlDataAdapter(ctQuery, conn);
                da.SelectCommand.Parameters.AddWithValue("@SoHDB", soHDB);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvChitiet.DataSource = dt;

                SetReadOnlyForTextBoxAndDateTimePicker(this, true);
                isViewingInvoice = true; // Đặt trạng thái xem hóa đơn

            }
        }

        private void SetReadOnlyForTextBoxAndDateTimePicker(Control parent, bool readOnly)
        {
            foreach (Control c in parent.Controls)
            {
                if (c is TextBox tb)
                {
                    tb.ReadOnly = readOnly;  // chỉ đọc, vẫn có thể chọn và copy
                }
                else if (c is DateTimePicker dtp)
                {
                    dtp.Enabled = !readOnly;  // disabled nếu readOnly = true
                }

                if (c.HasChildren)
                {
                    SetReadOnlyForTextBoxAndDateTimePicker(c, readOnly);
                }
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string soHDB = textBoxSoHDB.Text.Trim();
            if (string.IsNullOrEmpty(soHDB))
            {
                MessageBox.Show("Vui lòng nhập số hoá đơn.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DialogResult result = MessageBox.Show($"Bạn có chắc chắn muốn hủy hóa đơn {soHDB} không?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    SqlCommand cmd = new SqlCommand("sp_HuyHoaDonBan", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@SoHDB", soHDB);

                    SqlParameter ketQuaParam = new SqlParameter("@KetQua", SqlDbType.Int)
                    {
                        Direction = ParameterDirection.Output
                    };
                    cmd.Parameters.Add(ketQuaParam);

                    cmd.ExecuteNonQuery();
                    int ketQua = (int)ketQuaParam.Value;

                    if (ketQua == 0)
                    {
                        MessageBox.Show("Đã hủy hóa đơn thành công.", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        textBoxSoHDB.Clear();
                        textBoxMaKH.Clear();
                        textBoxTenKH.Clear();
                        textBoxDCKH.Clear();
                        textBoxSDTKH.Clear();
                        textBoxTongthanhtien.Clear();
                        dtChiTiet.Clear();
                        dgvChitiet.DataSource = dtChiTiet;
                        dgvChitiet.Refresh();
                        isViewingInvoice = false;
                        SetReadOnlyForTextBoxAndDateTimePicker(this, false);
                    }
                    else if (ketQua == 1)
                    {
                        MessageBox.Show($"Lỗi cộng lại số lượng đã bán", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else if (ketQua == 2)
                    {
                        MessageBox.Show($"Lỗi xoá chi tiết phiếu bán", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        MessageBox.Show($"Lỗi xoá hoá đơn bán", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Clear tất cả TextBox nhập liệu
            textBoxSoHDB.Clear();
            textBoxMaKH.Clear();
            textBoxTenKH.Clear();
            textBoxDCKH.Clear();
            textBoxSDTKH.Clear();
            textBoxTenHH.Clear();
            textBoxDongia.Clear();
            textBoxSoluong.Clear();
            textBoxThanhtien.Clear();
            textBoxMaHH.Clear();
            textBoxTongthanhtien.Clear();

            // Clear DataTable và cập nhật DataGridView
            dtChiTiet.Clear();
            dgvChitiet.DataSource = dtChiTiet;
            dgvChitiet.Refresh();
            isViewingInvoice = false;

            // Khôi phục trạng thái cho phép nhập liệu
            SetReadOnlyForTextBoxAndDateTimePicker(this, false);
        }

        private void textBoxSDTKH_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
