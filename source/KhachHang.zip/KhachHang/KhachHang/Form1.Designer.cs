﻿namespace KhachHang
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            textBoxMaKH = new TextBox();
            textBoxTenKH = new TextBox();
            textBoxDCKH = new TextBox();
            textBoxSDTKH = new TextBox();
            panel2 = new Panel();
            panel1 = new Panel();
            btnSua = new Button();
            btnLammoi = new Button();
            btnTimkiem = new Button();
            btnThem = new Button();
            dataGridKhachhang = new DataGridView();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridKhachhang).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.WindowText;
            label1.Location = new Point(636, 9);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(403, 35);
            label1.TabIndex = 0;
            label1.Text = "DANH MỤC KHÁCH HÀNG";
            label1.TextAlign = ContentAlignment.TopCenter;
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 12F, FontStyle.Bold);
            label2.ForeColor = SystemColors.HotTrack;
            label2.Location = new Point(26, 96);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(145, 23);
            label2.TabIndex = 1;
            label2.Text = "Mã khách hàng:";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 12F, FontStyle.Bold);
            label3.ForeColor = SystemColors.HotTrack;
            label3.Location = new Point(22, 165);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(149, 23);
            label3.TabIndex = 2;
            label3.Text = "Tên khách hàng:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 12F, FontStyle.Bold);
            label4.ForeColor = SystemColors.HotTrack;
            label4.Location = new Point(854, 103);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(75, 23);
            label4.TabIndex = 3;
            label4.Text = "Địa chỉ:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 12F, FontStyle.Bold);
            label5.ForeColor = SystemColors.HotTrack;
            label5.Location = new Point(854, 172);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(125, 23);
            label5.TabIndex = 4;
            label5.Text = "Số điện thoại:";
            // 
            // textBoxMaKH
            // 
            textBoxMaKH.Font = new Font("Times New Roman", 12F);
            textBoxMaKH.Location = new Point(225, 96);
            textBoxMaKH.Margin = new Padding(4, 3, 4, 3);
            textBoxMaKH.Name = "textBoxMaKH";
            textBoxMaKH.Size = new Size(398, 30);
            textBoxMaKH.TabIndex = 5;
            textBoxMaKH.TextChanged += textboxMaKH_TextChanged;
            // 
            // textBoxTenKH
            // 
            textBoxTenKH.Font = new Font("Times New Roman", 12F);
            textBoxTenKH.Location = new Point(225, 165);
            textBoxTenKH.Margin = new Padding(4, 3, 4, 3);
            textBoxTenKH.Name = "textBoxTenKH";
            textBoxTenKH.Size = new Size(398, 30);
            textBoxTenKH.TabIndex = 6;
            textBoxTenKH.TextChanged += textBoxTenKh_TextChanged;
            // 
            // textBoxDCKH
            // 
            textBoxDCKH.Font = new Font("Times New Roman", 12F);
            textBoxDCKH.Location = new Point(1028, 96);
            textBoxDCKH.Margin = new Padding(4, 3, 4, 3);
            textBoxDCKH.Name = "textBoxDCKH";
            textBoxDCKH.Size = new Size(405, 30);
            textBoxDCKH.TabIndex = 7;
            // 
            // textBoxSDTKH
            // 
            textBoxSDTKH.Font = new Font("Times New Roman", 12F);
            textBoxSDTKH.Location = new Point(1030, 165);
            textBoxSDTKH.Margin = new Padding(4, 3, 4, 3);
            textBoxSDTKH.Name = "textBoxSDTKH";
            textBoxSDTKH.Size = new Size(404, 30);
            textBoxSDTKH.TabIndex = 8;
            // 
            // panel2
            // 
            panel2.Controls.Add(textBoxSDTKH);
            panel2.Controls.Add(textBoxDCKH);
            panel2.Controls.Add(panel1);
            panel2.Controls.Add(textBoxTenKH);
            panel2.Controls.Add(textBoxMaKH);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(label1);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Margin = new Padding(4, 3, 4, 3);
            panel2.Name = "panel2";
            panel2.Size = new Size(1552, 367);
            panel2.TabIndex = 1;
            panel2.Paint += panel2_Paint;
            // 
            // panel1
            // 
            panel1.Controls.Add(btnSua);
            panel1.Controls.Add(btnLammoi);
            panel1.Controls.Add(btnTimkiem);
            panel1.Controls.Add(btnThem);
            panel1.Location = new Point(-100, 232);
            panel1.Margin = new Padding(4, 3, 4, 3);
            panel1.Name = "panel1";
            panel1.Size = new Size(1914, 113);
            panel1.TabIndex = 0;
            // 
            // btnSua
            // 
            btnSua.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            btnSua.Location = new Point(555, 32);
            btnSua.Margin = new Padding(4, 3, 4, 3);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(257, 45);
            btnSua.TabIndex = 5;
            btnSua.Text = "Sửa";
            btnSua.UseVisualStyleBackColor = true;
            btnSua.Click += button1_Click_2;
            // 
            // btnLammoi
            // 
            btnLammoi.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            btnLammoi.Location = new Point(954, 32);
            btnLammoi.Margin = new Padding(4, 3, 4, 3);
            btnLammoi.Name = "btnLammoi";
            btnLammoi.Size = new Size(257, 45);
            btnLammoi.TabIndex = 4;
            btnLammoi.Text = "Làm mới";
            btnLammoi.UseVisualStyleBackColor = true;
            btnLammoi.Click += button1_Click_1;
            // 
            // btnTimkiem
            // 
            btnTimkiem.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            btnTimkiem.Location = new Point(1341, 32);
            btnTimkiem.Margin = new Padding(4, 3, 4, 3);
            btnTimkiem.Name = "btnTimkiem";
            btnTimkiem.Size = new Size(267, 45);
            btnTimkiem.TabIndex = 3;
            btnTimkiem.Text = "Tìm kiếm";
            btnTimkiem.UseVisualStyleBackColor = true;
            btnTimkiem.Click += btnTimkiem_Click;
            // 
            // btnThem
            // 
            btnThem.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            btnThem.Location = new Point(141, 32);
            btnThem.Margin = new Padding(4, 3, 4, 3);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(257, 45);
            btnThem.TabIndex = 0;
            btnThem.Text = "Thêm";
            btnThem.UseVisualStyleBackColor = true;
            btnThem.Click += button1_Click;
            // 
            // dataGridKhachhang
            // 
            dataGridKhachhang.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridKhachhang.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridKhachhang.Dock = DockStyle.Fill;
            dataGridKhachhang.Location = new Point(0, 367);
            dataGridKhachhang.Margin = new Padding(4, 3, 4, 3);
            dataGridKhachhang.Name = "dataGridKhachhang";
            dataGridKhachhang.RowHeadersWidth = 51;
            dataGridKhachhang.Size = new Size(1552, 619);
            dataGridKhachhang.TabIndex = 2;
            dataGridKhachhang.CellContentClick += dataGridKhachhang_CellContentClick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(11F, 22F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.InactiveBorder;
            ClientSize = new Size(1552, 986);
            Controls.Add(dataGridKhachhang);
            Controls.Add(panel2);
            DoubleBuffered = true;
            Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ForeColor = SystemColors.ControlText;
            Margin = new Padding(4, 3, 4, 3);
            Name = "Form1";
            Text = "Danh mục khách hàng";
            Load += Form1_Load;
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridKhachhang).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox textBoxMaKH;
        private TextBox textBoxTenKH;
        private TextBox textBoxDCKH;
        private TextBox textBoxSDTKH;
        private Panel panel2;
        private Panel panel1;
        private Button btnTimkiem;
        private Button btnThem;
        private DataGridView dataGridKhachhang;
        private Button btnLammoi;
        private Button btnSua;
    }
}
