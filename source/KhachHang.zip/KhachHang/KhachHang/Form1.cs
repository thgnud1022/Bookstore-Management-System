﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
namespace KhachHang
{
    public partial class Form1 : Form
    {
        string connectionString = "Data Source=DESKTOP-658G9LP;Initial Catalog=QLCH;Integrated Security=True;TrustServerCertificate=True";
        public Form1()
        {
            InitializeComponent();
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private bool KiemTraSDTHopLe(string sdt, out string message)
        {
            message = "";
            if (string.IsNullOrWhiteSpace(sdt))
            {
                message = "Vui lòng nhập số điện thoại.";
                return false;
            }

            if (!sdt.All(char.IsDigit))
            {
                message = "Số điện thoại chỉ được chứa chữ số.";
                return false;
            }

            if (sdt.Length != 10)
            {
                message = "Số điện thoại phải gồm 10 chữ số.";
                return false;
            }

            string[] dauSoHopLe =
            {
                "032", "033", "034", "035", "036", "037", "038", "039",
                "086", "081", "082", "083", "084", "085",
                "070", "076", "077", "078", "079",
                "056", "058", "059"
            };

            string dauSo = sdt.Substring(0, 3);
            if (!dauSoHopLe.Contains(dauSo))
            {
                message = "Đầu số điện thoại không hợp lệ.";
                return false;
            }

            return true;
        }

        private bool KiemTraSDTTheoO(string sdt, out string message)
        {
            return KiemTraSDTHopLe(sdt, out message);
        }

        private bool ValidateCustomerName(string name, out string message)
        {
            message = "";
            if (string.IsNullOrWhiteSpace(name))
            {
                message = "Vui lòng nhập tên khách hàng.";
                return false;
            }

            if (!Regex.IsMatch(name, @"^[\p{L}\s]+$"))
            {
                message = "Tên khách hàng không hợp lệ (chỉ chứa chữ và dấu cách).";
                return false;
            }

            return true;
        }
        private bool ValidateAddress(string address, out string message)
        {
            message = "";
            if (string.IsNullOrWhiteSpace(address))
            {
                message = "Vui lòng nhập địa chỉ khách hàng.";
                return false;
            }

            if (!Regex.IsMatch(address, @"^[\p{L}0-9\s,./-]+$"))
            {
                message = "Địa chỉ không hợp lệ.";
                return false;
            }

            return true;
        }

        private bool ValidateInputs(out string message)
        {
            message = "";

            if (!KiemTraSDTHopLe(textBoxSDTKH.Text.Trim(), out message))
                return false;

            if (!ValidateCustomerName(textBoxTenKH.Text.Trim(), out message))
                return false;

            if (!ValidateAddress(textBoxDCKH.Text.Trim(), out message))
                return false;

            return true;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxSDTKH.Text) ||
            string.IsNullOrWhiteSpace(textBoxTenKH.Text) ||
            string.IsNullOrWhiteSpace(textBoxDCKH.Text))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Dừng xử lý tiếp
            }
            if (!ValidateInputs(out string msg))
            {
                MessageBox.Show(msg, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string ten = textBoxTenKH.Text.Trim();
            string diaChi = textBoxDCKH.Text.Trim();
            string sdt = textBoxSDTKH.Text.Trim();

            using (SqlConnection con = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand("AddKH", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@SDT", sdt);
                cmd.Parameters.AddWithValue("@TenKH", ten);
                cmd.Parameters.AddWithValue("@DiaChi", diaChi);

                SqlParameter maKHOut = new SqlParameter("@MaKH", SqlDbType.Char, 10)
                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter kqOut = new SqlParameter("@kq3", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                cmd.Parameters.Add(maKHOut);
                cmd.Parameters.Add(kqOut);

                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();

                    int result = (int)kqOut.Value;
                    switch (result)
                    {
                        case 0:
                            string maKH = maKHOut.Value.ToString().Trim();
                            MessageBox.Show($"Thêm thành công! Mã KH: {maKH}", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadKhachHang();
                            break;
                        case 1:
                            MessageBox.Show("Thêm thất bại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            break;
                        case 2:
                            MessageBox.Show("Khách hàng đã tồn tại.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            break;
                        default:
                            MessageBox.Show($"Lỗi không xác định. Mã lỗi: {result}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            break;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi thêm khách hàng: " + ex.Message);
                }
            }
        }


        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBoxTenKh_TextChanged(object sender, EventArgs e)
        {

        }

        private void LoadKhachHang()
        {
            try
            {
                string query = "SELECT * FROM KHACHHANG";
                using (SqlConnection con = new SqlConnection(connectionString))
                using (SqlDataAdapter adapter = new SqlDataAdapter(query, con))
                {
                    DataSet ds = new DataSet();
                    adapter.Fill(ds, "KhachHang");
                    dataGridKhachhang.DataSource = ds.Tables["KhachHang"];
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tải dữ liệu: " + ex.Message);
            }
        }


        private void dataGridKhachhang_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textboxMaKH_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadKhachHang();
            textBoxMaKH.ReadOnly = true;

            textBoxSDTKH.KeyDown += TextBox_KeyDown_Validate;
            textBoxTenKH.KeyDown += TextBox_KeyDown_Validate;
            textBoxDCKH.KeyDown += TextBox_KeyDown_Validate;


        }

        private void btnTimkiem_Click(object sender, EventArgs e)
        {
            string sdt = textBoxSDTKH.Text.Trim();
            if (!KiemTraSDTHopLe(sdt, out string msg))
            {
                MessageBox.Show(msg, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand("sp_TimkiemSDT", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@SDT", sdt);

                SqlParameter reOut = new SqlParameter("@re", SqlDbType.Int) { Direction = ParameterDirection.Output };
                cmd.Parameters.Add(reOut);

                try
                {
                    con.Open();

                    // Thực thi stored procedure trả về 1 hoặc 0 qua output parameter @re
                    cmd.ExecuteNonQuery();

                    int re = (int)reOut.Value;
                    if (re == 1)
                    {
                        MessageBox.Show("Không tìm thấy khách hàng.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    // Nếu tìm thấy, đọc dữ liệu
                    cmd.Parameters.Remove(reOut); // Bỏ output param để dùng ExecuteReader

                    using (SqlCommand cmd2 = new SqlCommand("SELECT MaKH, TenKH, DCKH FROM KHACHHANG WHERE SDTKH = @SDT", con))
                    {
                        cmd2.Parameters.AddWithValue("@SDT", sdt);
                        using (SqlDataReader reader = cmd2.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                textBoxMaKH.Text = reader["MaKH"].ToString();
                                textBoxTenKH.Text = reader["TenKH"].ToString();
                                textBoxDCKH.Text = reader["DCKH"].ToString();

                                // Khóa các textbox để không sửa
                                textBoxMaKH.ReadOnly = true;
                                textBoxTenKH.ReadOnly = false;
                                textBoxDCKH.ReadOnly = false;
                                textBoxSDTKH.ReadOnly = false;
                                btnThem.Enabled = false;
                                btnSua.Enabled = true;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi tìm kiếm: " + ex.Message);
                }
            }

        }

        private void ClearTextBoxes()
        {
            textBoxSDTKH.Clear();
            textBoxMaKH.Clear();
            textBoxTenKH.Clear();
            textBoxDCKH.Clear();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            ClearTextBoxes();

            // Cho phép người dùng nhập dữ liệu (bỏ chế độ chỉ đọc nếu trước đó đã khóa)
            textBoxMaKH.ReadOnly = false;
            textBoxTenKH.ReadOnly = false;
            textBoxDCKH.ReadOnly = false;
            textBoxSDTKH.ReadOnly = false;
            
            // Đưa con trỏ về ô SDT để người dùng nhập
            textBoxSDTKH.Focus();
            btnThem.Enabled = true;
        }

        private void TextBox_KeyDown_Validate(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // 2. Lấy TextBox hiện tại đã kích hoạt sự kiện
                TextBox currentTextBox = sender as TextBox;
                if (currentTextBox == null) return; // Đảm bảo sender là một TextBox

                string inputValue = currentTextBox.Text.Trim(); // Lấy giá trị từ TextBox
                string msg = string.Empty; // Chuỗi để chứa thông báo lỗi
                bool isValid = true;       // Biến cờ để đánh dấu hợp lệ hay không

                // 3. Dựa vào tên (hoặc tham chiếu) của TextBox để gọi hàm kiểm tra hợp lệ tương ứng
                if (currentTextBox == textBoxSDTKH)
                {
                    isValid = KiemTraSDTHopLe(inputValue, out msg);
                }
                else if (currentTextBox == textBoxTenKH)
                {
                    isValid = ValidateCustomerName(inputValue, out msg);
                }
                else if (currentTextBox == textBoxDCKH)
                {
                    isValid = ValidateAddress(inputValue, out msg);
                }
                // else if (currentTextBox == someOtherTextBox) { // Thêm các điều kiện khác nếu có nhiều TextBox }

                // 4. Xử lý kết quả kiểm tra
                if (!isValid) // Nếu dữ liệu không hợp lệ
                {
                    MessageBox.Show(msg, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error); // Hiển thị thông báo lỗi

                    // **Chỉ xóa dữ liệu của chính ô TextBox hiện tại**
                    currentTextBox.Text = string.Empty;

                    currentTextBox.Focus();    // Giữ con trỏ chuột tại ô bị lỗi
                    currentTextBox.SelectAll(); // Chọn toàn bộ nội dung để người dùng dễ dàng nhập lại

                    // Ngăn chặn hành vi mặc định của phím Enter (ví dụ: chuyển focus, tiếng "bíp")
                    e.SuppressKeyPress = true;
                    e.Handled = true;
                }
                else // Nếu dữ liệu hợp lệ
                {
                    // Cho phép phím Enter thực hiện hành vi mặc định là chuyển focus
                    // sang control tiếp theo trong Tab Order của form.
                    this.SelectNextControl(currentTextBox, true, true, true, true);
                    e.Handled = true; // Đánh dấu sự kiện đã được xử lý
                }
            }
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
           
            string maKH = textBoxMaKH.Text.Trim();
            string tenKH = textBoxTenKH.Text.Trim();
            string diaChi = textBoxDCKH.Text.Trim();
            string sdt = textBoxSDTKH.Text.Trim();

            // Kiểm tra số điện thoại
            if (!KiemTraSDTHopLe(sdt, out string msgSDT))
            {
                MessageBox.Show(msgSDT, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Kiểm tra tên khách hàng
            if (!ValidateCustomerName(tenKH, out string msgTen))
            {
                MessageBox.Show(msgTen, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Kiểm tra địa chỉ
            if (!ValidateAddress(diaChi, out string msgDC))
            {
                MessageBox.Show(msgDC, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand("UpdateKH", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MaKH", maKH);
                cmd.Parameters.AddWithValue("@TenKH", tenKH);
                cmd.Parameters.AddWithValue("@DiaChi", diaChi);
                cmd.Parameters.AddWithValue("@SoDienThoai", sdt);

                SqlParameter reOut = new SqlParameter("@re", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(reOut);

                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    int kq = (int)reOut.Value;

                    if (kq == 0)
                    {
                        MessageBox.Show("Cập nhật thông tin khách hàng thành công.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadKhachHang(); // làm mới danh sách nếu cần
                        textBoxMaKH.Clear();
                        textBoxTenKH.Clear();
                        textBoxDCKH.Clear();
                        textBoxSDTKH.Clear();
                        btnThem.Enabled = true;
                        btnSua.Enabled = false;
                    }
                    else
                    {
                        MessageBox.Show("Cập nhật thất bại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi cập nhật: " + ex.Message);
                }
            }
        }
    }
    

}
